import numpy as np
import cv2

path = "C:\\PRAJWAL_S_RAO\\NITK\\ACADEMICS\\MAJOR PROJECT\\CODE\\DSD_PROJECT\\Flower.bmp"
image = cv2.imread(path)

up = np.zeros(image.shape)
down = np.zeros(image.shape)
right = np.zeros(image.shape)
left = np.zeros(image.shape)
rightup = np.zeros(image.shape)
rightdown = np.zeros(image.shape)
leftup = np.zeros(image.shape)
leftdown = np.zeros(image.shape)

padded_image = cv2.copyMakeBorder(image,1,1,1,1,cv2.BORDER_REPLICATE,None,0)


for k in range(padded_image.shape[2]):
    for i in range(1,padded_image.shape[0] - 2):
        for j in range(1,padded_image.shape[1] - 2):
            up[i][j][k] = padded_image[i-1][j][k]
            down[i][j][k] = padded_image[i+1][j][k]
            right[i][j][k] = padded_image[i][j-1][k]
            left[i][j][k] = padded_image[i][j+1][k]
            rightup[i][j][k] = padded_image[i-1][j-1][k]
            rightdown[i][j][k] = padded_image[i+1][j-1][k]
            leftup[i][j][k] = padded_image[i-1][j+1][k]
            leftdown[i][j][k] = padded_image[i-1][j+1][k]

cv2.imwrite("center.bmp",image)
cv2.imwrite("up.bmp",up)
cv2.imwrite("down.bmp",down)
cv2.imwrite("right.bmp",right)
cv2.imwrite("left.bmp",left)
cv2.imwrite("rightup.bmp",rightup)
cv2.imwrite("rightdown.bmp",rightdown)
cv2.imwrite("leftup.bmp",leftup)
cv2.imwrite("leftdown.bmp",leftdown)




